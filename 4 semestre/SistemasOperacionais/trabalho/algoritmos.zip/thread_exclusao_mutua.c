//inclusão de bibliotecas
#include <pthread.h>
#include <stdio.h>
//fim inclusão
pthread_t tid1, tid2;//declaração dos threads
long conta=0;//declaração da variável conta compartilhada entre os threads
void * t1(){//declaração de uma função que pode retornar um ponteiro nulo, que recebe qualquer tipo de dados
	long i;//declaração variável i
	for(i=0; i< 1000000; i++){
		conta +=5;
	}
	printf("Fim t1\n");
}
void * t2(){
	long i;
	for(i=0; i<1000000; i++){
		conta+=2;
	}
	printf("Fim t2\n");
}
int main(){//função principal, inicia todas as chamadas do algoritmo
	pthread_create(&tid1, NULL, t1, NULL);//cria e executa a thread
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid2, NULL);
	pthread_join(tid1, NULL);//força o processo pai esperar o término do processo filho
	printf("\n\nO Valor de conta e: %li\n",conta);
}






