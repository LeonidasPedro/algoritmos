#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
pthread_mutex_t lock;
pthread_t tid1, tid2;
long conta=0;
void * t1(){
	long i;
	pthread_mutex_lock(&lock);
	for(i=0; i< 1000000000; i++){
		conta +=5;
	}
	pthread_mutex_unlock(&lock);
	printf("Fim t1\n");
}
void * t2(){
	long i;
	pthread_mutex_lock(&lock);
	for(i=0; i<1000000000; i++){
		conta+=2;
	}
	pthread_mutex_unlock(&lock);
	printf("Fim t2\n");
}
int main(){
	pthread_mutex_init(&lock, NULL);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	pthread_mutex_destroy(&lock);
	printf("O Valor de conta e: %li\n",conta);
}
