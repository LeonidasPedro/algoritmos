#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
int main(){
	int pid, i=60;
	pid = fork();
	if(pid==0){
		for(i;i<100;i++){
		printf("Processo filho %d i=%d.\n",getpid(),i);
		}
		return 7;
	} else {
		i=98;
		int ret1, status1;
		//ret1 = wait(&status1);
		for(i;i<100;i++){
		printf("Processo pai %d i=%d.\n",getpid(),i);
		}
	}
}
