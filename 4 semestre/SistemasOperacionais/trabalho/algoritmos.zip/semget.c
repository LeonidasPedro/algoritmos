#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#define KEY 1235
//IPC_CREAT|IPC_EXCL|0600
int main(){
	int semid;
	if((semid = semget(KEY, 4, IPC_CREAT|0600))==-1){
		printf("Erro ao criar o semaforo\n");
		exit(0);
	}
	printf("Semaforos criados id: %d\nCom chave %d\n",semid,KEY);
	exit(0);
}
//ipcs -s
//ipcrm sem 000
