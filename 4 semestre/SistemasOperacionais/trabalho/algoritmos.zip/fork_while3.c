#include <stdio.h>
#include <unistd.h>
int main(){
	int id, i=0, vet[3],n =0;
	while(i<3){
		id = fork();
		for(n=0;n<3;n++){
			printf("Digite 3 valores %d\n", getpid());
//			scanf("%d",&vet[n]);
		}
		i++;
	}
}
