#include <stdio.h>
#include <unistd.h>
//int execvp(const char *arquivo, char *const argv[])
int main(){
	int ret;
	char *cmd[] = { "ls", "-AlF", (char *)0};
	printf("Chamando o cat para imprimir a mensagem\n");
	ret = execvp("ls", cmd);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	return 0;
}
