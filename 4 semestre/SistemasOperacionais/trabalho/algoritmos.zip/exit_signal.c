#include <stdio.h>
#include <unistd.h>
#include <wait.h>
int main(){
	int pid, status;
	printf("Pid %d terminarei um filho com sinal 5\n",getpid());
	pid=fork();
	if(pid==0){
		printf("Filho %d\n",getpid());
		sleep(1);
		return -1;
	}else{
		printf("Aguardando o filho\n");
		wait(&status);
		if(WIFSIGNALED(status)){
			printf("Filho terminou ok\n");
		}else{
			printf("Filho terminou com erro %d\n",WEXITSTATUS(status));
		}
	}
	printf("saindo");
	return 10;
}
