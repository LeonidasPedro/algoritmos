#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>
#include <stdlib.h>
void meusinal(sig){
//	int sig;
	printf("\t\tRecebi o sinal %d\n",sig);
//	sleep(2);
//	exit(5);
//	return 5;
}
int main(){
	int pid;
	int status;
	printf("pid %d", getpid());
	pid=fork();
	if(pid==0){
	int i;
	for(i=1;i<20;i++)
		signal(i,meusinal);//instrução de o que fazer quando receber o sinal
		printf("processo filho %d\n",getpid());
		for(;;)
			sleep(1);
	} else {
		sleep(5);
		printf("Enviando o sinal 10");
		kill(pid,10);
		kill(pid,6);
		wait(&status);
		printf("Filho terminou com exit = %d\n",WEXITSTATUS(status));
	}
	return 0;
}
