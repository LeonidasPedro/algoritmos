#include <pthread.h>
#include <stdio.h>
pthread_t tid1, tid2;
int turn, flag[2];
long conta=0;
void * t1(){//Thread T1
	long i;
	for(i=0; i< 1000000; i++){
		flag[0]= 1;
		turn =0;
		while(flag[1]==1 && turn ==0){}
		conta = conta + 5;
		flag[0]=0;
	}
	printf("Fim t1\n");
}
void * t2(){
	long i;
	for(i=0; i<1000000; i++){
		flag[1]= 1;
		turn =1;
		while(flag[0]==1 && turn ==1){}
		conta =conta + 2;
		flag[1]=0;
	}
	printf("Fim t2\n");
}
int main(){
	flag[0]=1;
	flag[1]=0;
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	printf("O Valor de conta e: %li\n",conta);
}
