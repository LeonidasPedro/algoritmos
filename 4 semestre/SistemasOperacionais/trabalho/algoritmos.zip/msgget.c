#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#define KEY 1000
//verificar a fila ipcs -q
int main(){
	int msqid;
	char *caminho = "Caminho para um arquivo qualquer";
	if((msqid = msgget(KEY, IPC_CREAT|IPC_EXCL|0666))==-1){
		printf("Erro ao criar fila\n");
		return 1;
	}
	printf("identificador de fila%d\n",msqid);
	return 0;
}
