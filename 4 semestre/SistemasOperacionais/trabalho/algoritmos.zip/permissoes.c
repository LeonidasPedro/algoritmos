#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
//./permissoes permissoes.c
int main(int argv, char* argc[]){
	struct stat buffer;
	if(argv!=2)
		printf("uso: \npermissoes <arquivo>\n");
	else {
		if(!stat(argc[1],&buffer)){
			printf("Arquivo %s\n",argc[1]);
			printf("----------------------\n");
			printf("Id do dono: %d\n",buffer.st_uid);
			printf("Id do grupo: %d\n",buffer.st_gid);
			printf("permissoes do arquivo: %o\n",buffer.st_mode);
		}else{
			printf("Erro ao ler atributos\n");
		}
	}
	return 0;
}
