#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void * funcao_thread(void * arg){
	int i;
		printf("Iniciando thread %s.\n", (char *) arg);
		sleep(10);
		printf("Finalizando thread %s.\n", (char *) arg);
}
int main(){
	int retcode;
	pthread_t thread_a, thread_b;
	void * retval;
	printf("Criando o primeiro thread\n");
	retcode = pthread_create(&thread_a, NULL, funcao_thread, "a");
	if(retcode !=0){
		printf("O thread nao pode ser criado. Erro %d.\n", retcode);
	}
	sleep(1);
	printf("Criando o segundo thread\n");
	retcode = pthread_create(&thread_b, NULL, funcao_thread, "b");
	if(retcode!=0){
			printf("Erro %d thread nao criado\n",retcode);
	}
	sleep(1);
	printf("Esperando pelo termino do thread_a\n");
	retcode = pthread_join(thread_a, &retval);
	printf("Thread_a terminou\nEsperando thread_b\n");
	retcode = pthread_join(thread_b, &retval);
	printf("Tudo terminou =D\n");
	return 0;
}
