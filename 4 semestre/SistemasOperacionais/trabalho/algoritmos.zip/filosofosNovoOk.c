#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY1 123
#define KEY2 456
#define N 5
int filosofos[5]={0,0,0,0,0};
pthread_t fil1, fil2, fil3, fil4, fil5;
long conta=0;

int comer(int pos1, int pos2){
  if(filosofos[pos1]||filosofos[pos2])
    return 0;
  return 1;
}
void comendo(int pos){
  filosofos[pos]=1;
  printf("Filosofo %d comendo",pos);
}
void pensando(int pos){
  sleep(5);
  filosofos[pos]=0;
  printf("Filosofo %d pensando",pos);
}


void * f1(void * semaforo){
   printf("fil 1\n");
   printf("%d\n",*(int *) semaforo);
   while(!comer(4,1)){}
   comendo(0);
   P(*(int *) semaforo);
   pensando(0);
   V(*(int *) semaforo);
}
void * f2(void *semaforo){
   while(!comer(0,2)){}
   comendo(1);
	P(*(int *)semaforo);
   pensando(1);
	V(*(int *)semaforo);
}
void * f3(void *semaforo){
   while(!comer(1,3)){}
   comendo(2);
	P(*(int *)semaforo);
   pensando(2);	
   V(*(int *)semaforo);
}
void * f4(void *semaforo){
   while(!comer(2,4)){}
   comendo(3);
	P(*(int *)semaforo);
   pensando(3);
	V(*(int *)semaforo);
}
void * f5(void *semaforo){
   while(!comer(3,0)){}
   comendo(4);
	P(*(int *)semaforo);
   pensando(4);
	V(*(int *)semaforo);
}
int main(){
	int sem[5];
	int i;
	for(i=0;i<5;i++){
	  sem[i] = sem_create(KEY1+i, 1);
	  printf("Semaforo %d %d\n",sem[i],i);
	}
	char *x = (char *) &sem[0];
	char *semaforo[] = {(char *) &sem[0], (char *) &sem[1], (char *) &sem[2], (char *) &sem[3],(char *) &sem[4]};
//	printf("Um semaforo foi criado com o identificador %d\n",*(int *) x);
//	printf("Um semaforo foi criado com o identificador %d\n",*(int *) semaforo[3]);
//	printf("Um semaforo foi criado com o identificador %d\n",sem[0]);
	pthread_create(&fil1, NULL, f1, (void *) * semaforo);
	pthread_create(&fil2, NULL, f2, (void *) * semaforo);
	pthread_create(&fil3, NULL, f3, (void *) * semaforo);
	pthread_create(&fil4, NULL, f4, (void *) * semaforo);
	pthread_create(&fil5, NULL, f5, (void *) * semaforo);
	pthread_join(fil1, NULL);
	pthread_join(fil2, NULL);
	pthread_join(fil3, NULL);
	pthread_join(fil4, NULL);
	pthread_join(fil5, NULL);
	sem_delete(sem[0]);
	sem_delete(sem[1]);
	sem_delete(sem[2]);
	sem_delete(sem[3]);
	sem_delete(sem[4]);
}
