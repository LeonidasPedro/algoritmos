#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY1 123
#define KEY2 456
int sem1, sem2;
int sem, semoutro;
pthread_t tid1, tid2;
long conta=0;
void * t1(){
	P(sem1);
	printf("T1 fiz p0\n");
	long i;
	for(i=0; i< 1000000; i++){
		conta +=5;
	}
	//P(sem2);
	V(sem1);
	V(sem2);
	//printf("T1 fiz p1\n");
	printf("Encerrei t1\n");
}
void * t2(){
	printf("T2 fiz p1\n");
	P(sem2);
	P(sem1);
	printf("T2 fiz p0\n");
	long i;
	for(i=0; i<1000000; i++)
		conta+=2;
	printf("Encerrei t2\n");
	V(sem1);
	V(sem2);
}
int main(){
	sem1 = sem_create(KEY1, 1);
	sem2 = sem_create(KEY2, 1);
//	char *semaforo[] = {(char *)sem1, (char *)sem2};
	printf("Um semaforo foi criado com o identificador %d\n",sem1);
	printf("Um semaforo foi criado com o identificador %d\n",sem2);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	sem_delete(sem1);
	sem_delete(sem2);
	printf("O Valor de conta e: %li\n",conta);
}
