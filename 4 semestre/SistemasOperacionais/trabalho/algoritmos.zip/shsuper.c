#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <time.h>
#include <sys/types.h>
#define TAMANHO 100
int main(int argc, char *argv[]){
	int shmid, cntr;
	key_t chave;
	char *memoria;
	int tamanho = 1024;
	if(argc==1)
		ajuda();
	chave = ftok(".",'m');
	if((shmid = shmget(chave, TAMANHO, IPC_CREAT|IPC_EXCL|0666))==-1){
		printf("Abrindo segmento que j� existe\n");
		if((shmid=shmget(chave, TAMANHO, 0)==-1){
			printf("J� existe\n");
			return 1;
		}
	} else {
		printf("Criado\n");
	}
	printf("O segmento %d pode ser usado\n",shmid);
	if((int)(memoria= shmat(shmid,0,0))==-1){
		printf("Erro ao acoplar\n");
		return 1;
	}
	switch(tolower(argv[1][0])){
		case 'g':
			gravarmemoria(shmid, memoria, argv[2]);
			break;
		case 'l':
			lermemoria(shmid, memoria);
			break;
		case 'a':
			apagarsegmento(shmid);
			break;
		case 'p':
			mudarpermissao(shmid, argv[2]);
			break;
		default:
			ajuda();
	}
}
gravarmemoria(int shmid, char *memoria, char *mensagem)}
	strcpy(memoria, mensagem);
	printf("gravou\n");
}
lermemoria(int shmid, char *memoria){
	printf("lido %d", memoria);
}
apagarsegmento(int shmid){
	shmctl(shmid, IPC_RMID, 0);
	printf("Destruindo\n");
}
mudarpermissao(){
	struct shmid_ds shm_dados;
	shmctl(shmid, IPC_STAT, &shm_dados);
	printf("Permissoes eram %#o\n",shm_dados.shm_perm.mode&0777);
	sscanf(permissao, "%o", &shm_dados.shm_perm.mode);
	shmctl(shmid, IPC_SET, &shm_dados);
	printf("Novas permissoes %#o\n",shm_dados.shm_perm.mode&0777);
}
void ajuda(void){
	printf("\nFerramenta para trabalhar com memoria compartilhada\n");
	printf("\nAjuda: shsuper <comando> [opcao]\n");
	printf("\n(g)gravar <mensagem>\n");
	printf("\n(l)er \n");
	printf("\n(a)pagar\n");
	printf("\n(p)permissoes\n");
	return 1;
}