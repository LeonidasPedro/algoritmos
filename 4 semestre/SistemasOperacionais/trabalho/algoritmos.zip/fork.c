#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
int main(){
	int id;
	id = fork();
	if(id!=0){
		printf("Processo pai %d aguardando o filho %d\n",getpid(), id);
		wait(0);
		sleep(10);
		printf("O processo filho terminou o pai sera fechado\n");
	} else {
		printf("%d Processo filho %d dormindo por 10 segundos\n",id,getpid());
		sleep(10);
		printf("Filho terminado");
	}
}
