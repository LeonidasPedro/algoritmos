#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>

int main (int argc, char *argv[], char *envp[])
{
int pid ; /* identificador de processo */
pid = fork () ; /* replicac� �ao do processo */
if ( pid < 0 ) /* fork n�ao funcionou */
{
  perror ("Erro: ") ;
  exit (-1) ; /* encerra o processo */
}
else if ( pid > 0 ) /* sou o processo pai */
{
  wait (0) ; /* vou esperar meu filho concluir */
}
else /* sou o processo filho */
{
/* carrega outro c�odigo bin�ario para executar */
   execve ("/bin/date", argv, envp) ;
   perror ("Erro: ") ; /* execve n�ao funcionou */
}
printf ("Tchau !\n") ;
exit (0) ; /* encerra o processo */
}
