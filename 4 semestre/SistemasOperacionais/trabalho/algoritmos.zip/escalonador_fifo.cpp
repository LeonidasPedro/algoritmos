#include <cstdlib>
#include <iostream>

using namespace std;

int main()
{
    int var[2][5]={1,2,3,4,5,10,1,11,12,5};
    //srand((unsigned)time(0));
    int menor=1, maior=5,range=(maior-menor)+1;
    int rand_int;
    for(int i=0;i<5;i++){
            rand_int = menor+int(range*rand()/(RAND_MAX));
            printf("rand_int = %d+int(%d*%d)/(%d)\n",menor,range,rand(),RAND_MAX);
            //printf("Processo %d de %ds\n",var[0][i],var[1][i]);
            //printf("Rand %d\n", rand_int);
    }
    system("PAUSE");
    return EXIT_SUCCESS;
}
