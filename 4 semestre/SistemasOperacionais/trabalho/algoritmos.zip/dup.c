#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
int main(){
	int pipefd[2];
	pipe(pipefd);
	if(fork()==0){
		char *cmd[] = {"cat", "/etc/passwd", (char *)0};
		printf("Processo PID %d",getpid());
		close(1);
		dup(pipefd[1]);//conecta o pipe a sa�da padr�o do comando da linha 13
		close(pipefd[1]);
		close(pipefd[0]);
		execv("/bin/cat", cmd);//o resultado ser� escrito no pipe
	}
	if(fork()==0){
		char *cmd[] = {"grep", "root",(char *)0};
		printf("Processo PID %d",getpid());
		close(0);
		dup(pipefd[0]);//conecta o pipe a entrada padr�o do comando da linha 22
		close(pipefd[0]);
		close(pipefd[1]);
		execv("/bin/grep", cmd);//o resultado anterior ser� escrito neste comando pelo pipe
	}
	return 0;
}
//o resultado � equivalente ao comando cat /etc/passwd |grep root
