#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void * procuraprimo(void * arg){
	int numeroprimo = 2;
	int totalnumeros = *((int *) arg);
	printf("Calculando primos ate %d\nSao primos:\n",totalnumeros);
	while(1){
		int fatordivisao;
		int flagnumeroprimo=1;
		for(fatordivisao=2;fatordivisao<numeroprimo;++fatordivisao)
			if(numeroprimo % fatordivisao ==0)/*se nao e primo*/{
				flagnumeroprimo =0;
				break;
			}
			if(flagnumeroprimo)/*e primo so divide por 1 ele mesmo*/{
				printf("\t\t%d\n",numeroprimo);
				if(--totalnumeros==0)
					return (void *) numeroprimo;
			}
			++numeroprimo;
	}
	return NULL;
}
int main(){
	pthread_t thread;
	int total=10000;
	int primo;
	pthread_create(&thread, NULL, &procuraprimo, &total);
	pthread_join(thread, (void *) &primo);
	printf("\n\nO %d primo e %d.\n",total,primo);
	return 0;
}










