#include <stdio.h>
#include <unistd.h>
#include <locale.h>
int main(){
	setlocale(LC_ALL, "portuguese");
	printf("Eu sou o processo %d. Meu pai � %d. O grupo � %d.\n",getpid(), getppid(), getpgrp());
};
