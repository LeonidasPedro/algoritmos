#include <stdio.h>
#include <unistd.h>
//int execle(const char *arquivo, char *const argv[], char *const env[],...)
int main(){
	int ret;
	char *env[] = { "HOME=/home", "LOGNAME=home", (char *)0};
	printf("Chamando o cat para imprimir a mensagem com o echo\n");
	execle("/bin/ls", "ls", "-AlF", (char *)0, env);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	return 0;
}
