#include <unistd.h>
#include <stdio.h>
int main(){
	char *diretorio = getcwd(NULL, 0);
	printf("O diretorio eh: %s.\n",diretorio);
	return 0;
}
