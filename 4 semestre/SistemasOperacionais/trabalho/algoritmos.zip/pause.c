#include <unistd.h>
int pause(void);
#include <signal.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void alarme(int sig){
	printf("Sinal recebido %d.\n",sig);
	exit(0);
}
int main(){
	int retpausa;
	printf("Alarme a ser enviado em 5s.\n");
	signal(14, alarme);
	alarm(5);
	retpausa = pause();
	printf("Retorno pausa %d\n",retpausa);
	exit(0);
}
