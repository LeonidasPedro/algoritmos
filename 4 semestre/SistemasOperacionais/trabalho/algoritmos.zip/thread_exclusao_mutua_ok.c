#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY 1234
int sem;
pthread_t tid1, tid2;
long conta=0;
void * t1(){
	long i;
	P(sem);
	for(i=0; i< 1000000000; i++){
		conta +=5;
	}
	V(sem);
	printf("Fim t1\n");
}
void * t2(){
	long i;
	P(sem);
	for(i=0; i<1000000000; i++){
		conta+=2;
	}
	V(sem);
	printf("Fim t2\n");
}
int main(){
	sem = sem_create(KEY, 1);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	sem_delete(sem);
	printf("O Valor de conta e: %li\n",conta);
}
