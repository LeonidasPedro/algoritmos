#include <stdio.h>
#include <unistd.h>
int main(){
	printf("Pid %d terminando com sinal 10\n",getpid());
	sleep(5);
	return 10;
}
