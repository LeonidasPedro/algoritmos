#include <stdio.h>
#include <stdlib.h>
#define ARQUIVO_FIFO "FIFO"
//executar com ./escritor "Teste de FIFO"
int main(int argc, char *argv[]){
	FILE *fp;
	if(argc !=2){
		printf("Uso escritor\n");
		return 1;
	}
	if((fp=fopen(ARQUIVO_FIFO, "w"))==NULL){
		printf("Erro");
		return 1;
	}
	fputs(argv[1], fp);
	fclose(fp);
	return 0;
}