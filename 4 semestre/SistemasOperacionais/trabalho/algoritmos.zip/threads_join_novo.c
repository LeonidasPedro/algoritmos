//g++ -lm -pthread teste.cpp -o bin && ./bin
#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
int funcaoprocedural(){
	int i=0;
	while(i<10){
		i++;
		sleep(1);
		printf("Procedural %d\n",i);
	}
}
void funcaoprocedural1(){
	int i=0;
	while(i<10){
		i++;
		sleep(1);
		printf("Procedural1111111\n");
	}
}
void * funcao_thread(void * arg){
	int i=0;
	while(i<10){
		i++;
		printf("Thread 1 com pid %d\n",getpid());
		sleep(1);
	}
	return NULL;
}
void * funcao_thread1(void * arg){
	int i=0;
	while(i<10){
		i++;
		printf("Thread 2 com pid %d\n",getpid());
		sleep(1);
	}
	return NULL;
}

int main(){
	pthread_t thread,thread1;
//	funcaoprocedural();
//	funcaoprocedural1();
	printf("HWP pid %d\n",getpid());
	pthread_create(&thread, NULL, funcao_thread, NULL);
	pthread_create(&thread1, NULL, funcao_thread1, NULL);
	pthread_join(thread, NULL);
	pthread_join(thread1, NULL);
	printf("Saindo HWP\n");
	exit(0);
}
