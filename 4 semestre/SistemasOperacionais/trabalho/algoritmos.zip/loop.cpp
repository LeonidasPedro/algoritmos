#include <stdio.h>
#include <stdlib.h>
int main(){
	long long int x=0;
	while(1){
		x++;
		printf("\tloop %ld", x);
	}
}