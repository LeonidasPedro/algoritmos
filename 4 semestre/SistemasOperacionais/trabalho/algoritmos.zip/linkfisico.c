#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
int main(){
	printf("um link simbolico sera criado\n");
	int linksimbolico = symlink("links.c","linksimbolico.c");
	if(linksimbolico==0)
		printf("Link simbolico criado\n");
	printf("um link fisico sera criado\n");
	int linkfisico = link("links.c", "linkfisico.c");
	if(linkfisico==0)
		printf("link fisico criado\n");
	char nome[100];
	readlink("linksimbolico.c",nome,100);
	printf("o link simbolico linksimbolico.c aponta para o arquivo original %s\n",nome);
	return 0;
}
