#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/wait.h>
int main(){
	int pid;
	printf("Meu pid %d e meu pid de grupo %d\n",getpid(),getpgrp());
	pid = fork();
	if(pid==0){
		printf("Filho = Processo filho criado com o pid %d e grupo %d\n",getpid(), getpgrp());
		sleep(10);
		printf("Filho = Saindo com código 7");
		return 7;
	} else {
		int ret1, status1;
		printf("Pai = processo pai aguardando filho\n");
		sleep(3);
		printf("Pai = Mensagem entre a execução dos processos\n\n");
//		ret1 = wait(&status1);
		ret1 = waitpid(pid, &status1,WUNTRACED);
		printf("\nPai = O processo filho terminou era o pid %d\n seu retorno de saida foi %d\n",ret1,(status1));
	}
}





