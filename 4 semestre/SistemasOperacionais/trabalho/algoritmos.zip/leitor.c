#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <linux/stat.h>
#define ARQUIVO_FIFO "FIFO"
//executar leitor em segundo plano ./leitor &
int main(void){
	FILE *fp;
	char readbuf[80];
	umask(0);
	mknod(ARQUIVO_FIFO, S_IFIFO|0666,0);
	while(1){
		fp = fopen(ARQUIVO_FIFO, "r");
		fgets(readbuf, 80, fp);
		printf("conteudo %s\n",readbuf);
		fclose(fp);
	}
	return 0;
}