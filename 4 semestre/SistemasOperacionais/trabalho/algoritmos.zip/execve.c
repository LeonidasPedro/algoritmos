#include <stdio.h>
#include <unistd.h>
//o execve tem a mesma funcao das demais exec neste caso e permitido chamar programas que estejam alocados no path do SO
//as variaveis de PATH sao carregadas no inicio do bash, mas podem ser alteradas em tempo de execucao
//exemplo no terminal execute echo $PATH listara o conteudo da variavel de ambiente $PATH
//set lista todas as variaveis
//AULA = "Sistemas Operacionais" seta uma nova variavel
//echo $AULA lista o conteúdo
//int execve(const char *arquivo, char *const argv[], char *const env[])
int main(){
	char *cmd[] = { "echo", "SO", (char *)0};
	//cmd[] é um array de strings e necessariamente deve ser finalizado com um ponteiro nulo o (char *) 0
	char *env[] = { "AULA=SO", (char *)0};
	printf("Chamando o cat para imprimir a mensagem com o echo\n");
	execve("/bin/echo", cmd, env);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	return 0;
}
