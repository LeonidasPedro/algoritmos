#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
//int system(const char *string)
int main(){
	printf("Chamada\n");
	system("/bin/cat /etc/issue");
	system("/usr/sbin/ifconfig");
	printf("Agora esta mensagem e impressa\n");
	return 0;
}
