#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY 1235
int main(){
	int sem, i=0;
	sem = sem_create(KEY, 1);
	printf("Semaforo criado id: %d\n",sem);
	if(fork()==0){
		printf("\t\tProcesso filho usa o recurso.\n");
		P(sem);
		sleep(5);
		while(i<10){
		  i++;
		  printf("\t\tProcesso filho libera o recurso.\n");
		}
		V(sem);
		sleep(1);
	} else {
		sleep(1);
		printf("\t\tProcesso Pai bloqueia ao tentar acessar o recurso.\n");
		P(sem);
		printf("\t\tRecurso dispon�vel para o processo Pai.\n");
		V(sem);
		sem_delete(sem);
	}
	exit(0);
}
