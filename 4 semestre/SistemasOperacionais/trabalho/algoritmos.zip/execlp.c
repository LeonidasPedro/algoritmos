#include <stdio.h>
#include <unistd.h>
//int execle(const char *arquivo, char *const argv[], ...)
//a quantidade maxima de argumentos e gerenciada pelo SO para saber a quantidade maxima digite
//grep ARG_MAX /usr/include/linux/limits.h
//no terminal
int main(){
	int ret;
	char *cmd[] = { "ls", "-AlF", (char *)0};
	printf("Chamando o cat para imprimir a mensagem com o echo\n");
//	fflush(stdout);
	execv("/bin/ls", cmd);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	return 0;
}
