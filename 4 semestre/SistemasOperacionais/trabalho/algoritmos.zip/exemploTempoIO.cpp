//g++ -lm codigo.cpp -o bin && time ./bin 
#include <stdio.h>
#include <stdlib.h>
int main(){
	int x=0;
	while(x<1000000000){
		printf("%d", x);
		x++;
	}
}