#include <stdio.h>
#include <unistd.h>
int main(){
	int id;
	id = fork();
	id = fork();
	printf("Cópia de processos\n\n");
}
