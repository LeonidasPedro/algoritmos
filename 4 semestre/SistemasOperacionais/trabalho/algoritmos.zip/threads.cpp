#include <cstdlib>
#include <iostream>
#include <windows.h>
using namespace std;
DWORD WINAPI Thread1(LPVOID);            // Defini��o das fun��o de cada Thread: Thread1,Thread2,Thread3.
DWORD WINAPI Thread2(LPVOID);
DWORD WINAPI Thread3(LPVOID);

double soma = 0;
 double soma2 = 0;
 double soma3=0;

int main()
{
DWORD id[3];
HANDLE th[3];

th[0] = CreateThread(0,0,Thread1,0,0,&id[0]);           //Como vamos criar 3 threads utilizaremos arrays para armazenar,
th[1] = CreateThread(0,0,Thread2,0,0,&id[1]);           //os handlers e ID's de cada thread. Note que cada array possui 3
th[2] = CreateThread(0,0,Thread3,0,0,&id[2]);           //elementos e que t�m os �ndices: 0, 1 e 2.

SetThreadPriority(th[0],THREAD_PRIORITY_TIME_CRITICAL);
SetThreadPriority(th[1],THREAD_PRIORITY_TIME_CRITICAL);
//SetThreadPriority(th[2],THREAD_PRIORITY_LOWEST);
SetThreadPriority(th[2],THREAD_PRIORITY_TIME_CRITICAL);

if(th[0] == 0 || th[1] == 0 || th[2] == 0)
{
//MessageBox(0,"Ocorreu um erro ao criar as Threads","Erro",0x10);
return 1;
}

 //MessageBox(0,"Mensagem da fun��o MAIN","LOL",0x40);

WaitForMultipleObjects(3,th,1,INFINITE);                 // utilizamos a fun��o WaitForMultipleObjects() para aguardar o
                                                         //t�rmino da fun��o de cada Thread.
                                                          /* BOOL WINAPI WaitForMultipleObjects(DWORD num_threads,
                                                         HANDLE * thread_handle,BOOL esperar_todos, DWORD codigo_saida);
                                                          - num_threads: n�mero de threads;

                                                         - thread_handle: array que cont�m os handlers das threads;

                                                          - esperar_todos: Pode ser TRUE (1) ou FALSE (0).
                                                         Se 1, o programa aguarda at� todos os objetos, no caso as Threads sejam finalizadas;
                                                          Se 0, o programa aguarda at� que alguma das threads finalize.

                                                         - tempo:tempo em milisegundos que o programa deve aguardar. Caso a constante "INFINITE" seja especificada,
                                                          o programa aguarda o tempo necess�rio at� que a Thread seja finalizada, retornando um valor.  */


int i;

for(i = 0;i<3;i++)
{
TerminateThread(th[i],0);                                //para terminarmos uma Thread
 CloseHandle(th[i]);                                      //para fechar o Handle da Thread:
}
system("PAUSE");
return 0;
}

DWORD WINAPI Thread1(LPVOID p)
{
while(soma < 100){
      //printf("Thread 1   -  \n");
      soma += 0.001 + 0.001;
       soma = 0.001;
           }
return 0;
}

DWORD WINAPI Thread2(LPVOID p)
{
while(soma2 < 100){
      soma2 += 0.001 + 0.001;
      //printf("Thread 2");
      soma2 = 0.001;
           }
return 0;
}

 DWORD WINAPI Thread3(LPVOID p)
{
//MessageBox(0,"Mensagem da Thread 3","LOL",0x10);
while(soma3<100){
  soma3=0;
	//printf("Thread 3");
}
return 0;
}
