#include <stdio.h>
#include <unistd.h>
int main(){
	int id;
	id = fork();
	if(id!=0){
		printf("Processo pai aguardando o filho %d\n",id);
		wait(0);
		printf("O processo filho terminou o pai sera fechado\n");
	} else {
		printf("Processo filho %d dormindo por 10 segundos\n",getpid());
		sleep(10);
		printf("Filho terminado\n");
	}
}
