#include <cstdlib>
#include <iostream>
#include <windows.h>//biblioteca necess�ria para tipo DWORD
#define TAM 5
using namespace std;


DWORD WINAPI filosofo(LPVOID p);//Prototipagem da funcao que ser� thread
bool garfo[TAM];//Array booleano
int id = 0;

int main(int argc, char *argv[])
{
  DWORD idt[TAM];    
  HANDLE th[TAM];
  for(int i=0; i<TAM; i++)
    th[i] = CreateThread(0,0,filosofo,0,0,&idt[i]); 
  WaitForMultipleObjects(TAM,th,1,INFINITE);                       
  for(int i = 0;i<TAM;i++)
  {
     TerminateThread(th[i],0);                                
     CloseHandle(th[i]);                                      
  }
  CloseHandle(th);
    system("PAUSE");
    return EXIT_SUCCESS;
}

DWORD WINAPI filosofo(LPVOID p){//Funcao para comer e soltar garfos
  int atual = id++;
  int proximo = id;
  if(proximo == TAM) proximo = 0;
  while(true){
     printf("Filosofo %i esta buscando garfo\n", proximo);
     garfo[atual] = 1;
     garfo[proximo] = 1;
     printf("Filosofo %i esta comendo\n", proximo);
     Sleep(2000);
     garfo[atual] = 0;
     garfo[proximo] = 0;
     printf("Filosofo esta pensando %i\n", proximo);
     Sleep(2000);
  }
}
