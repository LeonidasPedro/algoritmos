#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY1 123
#define KEY2 456
int sem, semoutro;
pthread_t tid1, tid2;
long conta=0;
void * t1(char *semaforo[]){
	P((int *)semaforo[0]);
	printf("T1 fiz p0\n");
	long i;
	for(i=0; i< 1000000; i++){
		conta +=5;
	}
	P((int *)semaforo[1]);
	printf("T1 fiz p1\n");
	printf("Encerrei t1\n");
	V((int *)semaforo[0]);
//	V((int *)semaforo[1]);
}
void * t2(char *semaforo[]){
	P((int *)semaforo[1]);
	printf("T2 fiz p1\n");
	P((int *)semaforo[0]);
	printf("T2 fiz p0\n");
	long i;
	for(i=0; i<1000000; i++)
		conta+=2;
	printf("Encerrei t1\n");
//	V((int *)semaforo[1]);
	V((int *)semaforo[0]);
}
int main(){
	int sem1, sem2;
	sem1 = sem_create(KEY1, 1);
	sem2 = sem_create(KEY2, 1);
	char *semaforo[] = {(char *)sem1, (char *)sem2};
	printf("Um semaforo foi criado com o identificador %d\n",semaforo[0]);
	printf("Um semaforo foi criado com o identificador %d\n",semaforo[1]);
	pthread_create(&tid1, NULL, t1, semaforo);
	pthread_create(&tid2, NULL, t2, semaforo);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	sem_delete((int)semaforo[0]);
	sem_delete((int)semaforo[1]);
	printf("O Valor de conta e: %li\n",conta);
}
