#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void * processoleve1(){
	int i;
	for(i=1;i<100;i++){
		printf("\t\tThread 1 - %d\n",i);
	}
}
void * processoleve2(){
	int i;
	for(i=100;i<200;i++){
		printf("\t\tThread 2 - %d\n",i);
	}
}
int main(){
	pthread_t thread1, thread2;
	pthread_create(&thread1, NULL, processoleve1, NULL);
	pthread_detach(thread1);
	pthread_create(&thread2, NULL, processoleve2, NULL);
	pthread_join(thread1, NULL);
//	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
	pthread_detach(thread2);
//	sleep(5);
	printf("\t\tFIM\n");
}
