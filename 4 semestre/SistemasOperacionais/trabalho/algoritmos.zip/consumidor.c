#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include "biblioteca_dijkastra.h"
#define KEY 1234
pthread_t tid1, tid2;
int sem;
long conta=0;
void * t1(){
	long i;
	for(;;){
		P(sem);
		while(conta < 1000000000){
			conta++;
		}
		printf("Produtor ok %d", conta);
		V(sem);
	}
}
void * t2(){
	long i;
	while(1){
		P(sem);
		while(conta>0){
			conta--;
		}
		printf("   -   Consumidor ok %d\n", conta);
		V(sem);
	}
}
int main(){
	sem = sem_create(KEY, 1);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	sem_delete(sem);
}
