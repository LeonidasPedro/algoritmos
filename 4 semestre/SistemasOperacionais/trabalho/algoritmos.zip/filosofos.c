#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY1 123
#define KEY2 456
int filosofos[5]={0,0,0,0,0};
pthread_t fil1, fil2, fil3, fil4, fil5;
long conta=0;

int comer(int pos1, int pos2){
  if(filosofos[pos1]||filosofos[pos2])
    return 0;
  return 1;
}
void comendo(int pos){
  filosofos[pos]=1;
  printf("Filosofo %d comendo",pos);
}
void pensando(int pos){
  sleep(5);
  filosofos[pos]=0;
  printf("Filosofo %d pensando",pos);
}


void * f1(char *semaforo[]){
   printf("fil 1");
   while(!comer(4,1)){}
   comendo(0);
   P((int *)semaforo[4]);
   pensando(0);
   V((int *)semaforo[0]);
}
void * f2(char *semaforo[]){
   while(!comer(0,2)){}
   comendo(1);
	P((int *)semaforo[0]);
   pensando(1);
	V((int *)semaforo[1]);
}
void * f3(char *semaforo[]){
   while(!comer(1,3)){}
   comendo(2);
	P((int *)semaforo[1]);
   pensando(2);	
   V((int *)semaforo[2]);
}
void * f4(char *semaforo[]){
   while(!comer(2,4)){}
   comendo(3);
	P((int *)semaforo[2]);
   pensando(3);
	V((int *)semaforo[3]);
}
void * f5(char *semaforo[]){
   while(!comer(3,0)){}
   comendo(4);
	P((int *)semaforo[3]);
   pensando(4);
	V((int *)semaforo[4]);
}
int main(){
	int sem[5];
	int i;
	for(i=0;i<5;i++)
	  sem[i] = sem_create(KEY1, 1);
	char *semaforo[] = {(char *)sem[0], (char *)sem[1], (char *)sem[2], (char *)sem[3],(char *)sem[4]};
	printf("Um semaforo foi criado com o identificador %d\n",semaforo[0]);
	printf("Um semaforo foi criado com o identificador %d\n",semaforo[1]);
	pthread_create(&fil1, NULL, f1, semaforo);
	printf("teste");
/*	pthread_create(&fil2, NULL, f2, semaforo);
	pthread_create(&fil3, NULL, f3, semaforo);
	pthread_create(&fil4, NULL, f4, semaforo);
	pthread_create(&fil5, NULL, f5, semaforo);
	pthread_join(fil1, NULL);
	pthread_join(fil2, NULL);
	pthread_join(fil3, NULL);
	pthread_join(fil4, NULL);
	pthread_join(fil5, NULL);*/
	sem_delete((int)semaforo[0]);
	sem_delete((int)semaforo[1]);
	sem_delete((int)semaforo[2]);
	sem_delete((int)semaforo[3]);
	sem_delete((int)semaforo[4]);
}
