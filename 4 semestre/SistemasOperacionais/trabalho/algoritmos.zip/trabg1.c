#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include <dirent.h>
int main(){
	char diretorio[100]={"/arquivos/"}, arquivo[20], frase[200];
	int i=1, fd, bytes;
	printf("\t\tCriando diretório e arquivos");
	mkdir(diretorio,S_IRWXU|S_IRWXG|S_IROTH|S_IXOTH);
	for(i; i<5;i++){
		sprintf(arquivo,"%s%s%s%d%s","touch ",diretorio,"arq",i,".txt");
		system(arquivo);
	}
	printf("\n\t\tListando arquivos existentes:\n\n\n");
	DIR *dp;
	struct dirent *ep;
	dp = opendir(diretorio);
	if(dp !=NULL){
		while(ep=readdir(dp))
			printf("\t\t%s\n",ep->d_name);
		(void) closedir (dp);
	} else
		puts("nao foi possivel abrir o diretorio\n");
	printf("\n\n\t\tDigite o nome do arquivo a editar: ");
	scanf("%s",arquivo);
	printf("O arquivo %s foi aberto para gravacao, digite a frase a ser gravada: ",arquivo);
	strcat(diretorio,arquivo);
	fd = open(diretorio, O_WRONLY|O_TRUNC);
	scanf("%s",frase);
	write(fd,frase,strlen(frase));
	close(fd);
}
