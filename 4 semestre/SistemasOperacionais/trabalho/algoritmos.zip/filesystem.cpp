#include <sys/types.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <wait.h>
#include <string.h>


#include <sys/stat.h>
#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
using namespace std;
int main(){
	char diretorio[100], arquivo[100];
	int numbytes, fd;
	string frase;
	printf("Digite o nome do diretório");
	scanf("%s",&diretorio);
	const int dir_err = mkdir(diretorio, 0777);
	if (-1 == dir_err){
		printf("Error creating directory!\n");
		exit(1);
	}
	string ss = string("touch ")+string(diretorio)+string("/file1.txt");
	system(ss.c_str());
	ss = string("touch ")+string(diretorio)+string("/file2.txt");
	system(ss.c_str());
	ss = string("touch ")+string(diretorio)+string("/file3.txt");
	system(ss.c_str());
	ss = string("touch ")+string(diretorio)+string("/file4.txt");
	system(ss.c_str());
	ss = string("dir ")+string(diretorio);
	system(ss.c_str());
	printf("Digite o nome do arquivo: ");
	scanf("%s",&arquivo);
	ss = string(diretorio)+"/"+string(arquivo);
	ofstream out(ss);
	frase = "Este arquivo foi criado para exemplificar escrita e leitura de seu conteudo";
	out << frase;
	out.close();
	return 0;
}
