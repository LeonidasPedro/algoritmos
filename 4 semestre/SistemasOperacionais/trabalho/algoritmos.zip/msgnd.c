#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/types.h>
#include <unistd.h>
#define KEY 100
int main(){
	int msqid;
	char *caminho = "/etc/passwd";
	int tamanhomensagem;
	struct meu_msgbuf{
		long mtype;
		long cliente_id;
		char cliente_nome[80];
		char cliente_telefone[15];
		char cliente_endereco[180];
		char cliente_cidade[30];
		char cliente_estado[2];
	} mensagem;
	if((msqid = msgget(ftok("teste",(key_t)KEY), IPC_CREAT|0666))==-1){
		printf("Erro ao criar fila\n");
		return 1;
	}
	printf("A chave %#x foi usada para criar o id da fila\n",ftok("teste",(key_t)KEY));
	printf("id da fila %d\nEnviando mensagem para a fila\n",msqid);
	mensagem.mtype=1;
	mensagem.cliente_id = 1234;
	sprintf(mensagem.cliente_nome,"Nome do cliente");
	sprintf(mensagem.cliente_telefone,"0000-0000");
	sprintf(mensagem.cliente_endereco,"Avenida Nova");
	sprintf(mensagem.cliente_cidade,"Cidade");
	sprintf(mensagem.cliente_estado,"SC");
	tamanhomensagem = sizeof(mensagem)-4;
	printf("tamanho da mensagem %d\n",tamanhomensagem);
	if(msgsnd(msqid, &mensagem, tamanhomensagem,IPC_NOWAIT)==-1){
		printf("erro\n");
		return -1;
	} else {
		printf("mensagem enviada\n");
	}
	return 0;
}
