#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void * processoleve1(void * arg, void * arg2){
char comando[100];
//system("mpiexec -host micro /pentest/passwords/john/john --format:raw-MD5 /root/rt08");
	strcat(comando, arg);
	strcat(comando, arg2)
	system(comando);
}
main(){
	pthread_t thread1, thread2, thread3;
//	while(){
	pthread_create(&thread1, NULL, processoleve1, "rt08 /pentest/passwords/john/john --format:raw-MD5 /root/rt08");
	pthread_create(&thread1, NULL, processoleve1, "rt09 /pentest/passwords/john/john --format:raw-MD5 /root/rt09");
//	}
//	while()
	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);
	pthread_join(thread3, NULL);
//	}
}
