#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include <dirent.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "biblioteca_dijkastra.h"
#define KEY 1234
int conta=0, sem;
pthread_t tid1, tid2;
void * t1(){
	int i;
	while(1){
		P(sem);
		printf("\t\tProdutor %d\n\n",conta);
		for(i=0; i< 100; i++)
			conta++;
		sleep(1);
		printf("\t\tFim produtor\n");
		V(sem);
	}
}
void * t2(){
	int i;
	while(1){
		P(sem);
		printf("\t\tConsumidor %d\n\n",conta);
		for(i=0; i< 100; i++)
			conta--;
		sleep(1);
		printf("\t\tFim consumidor\n");
		V(sem);
	}
}
int main(){
	sem = sem_create(KEY, 1);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	sem_delete(sem);
	printf("O Valor de conta e: %d\n",conta);
}
