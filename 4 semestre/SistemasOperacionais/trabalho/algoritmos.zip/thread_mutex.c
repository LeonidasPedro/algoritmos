#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

pthread_t tid1, tid2;
pthread_mutex_t lock;
long conta=0;
void * produtor(){
	long i;
	while(1){
		pthread_mutex_lock(&lock);
		if(conta < 1000000){
			for(i=0; i< 1000000; i++){
				conta +=1;
			}
			printf("Fim Produtor %li\n", conta);
		}
		pthread_mutex_unlock(&lock);
	}
}
void * consumidor(){
	long i;
	while(1){
		pthread_mutex_lock(&lock);
		if(conta > 0){
			for(i=0; i<1000000; i++){
				conta-=1;
			}
			printf("Fim Consumidor %li\n", conta);
		}
		pthread_mutex_unlock(&lock);
	}
}
int main(){
	pthread_create(&tid1, NULL, produtor, NULL);
	pthread_create(&tid2, NULL, consumidor, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	pthread_mutex_destroy(&lock);
}
