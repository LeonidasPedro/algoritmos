#include <unistd.h>
#include <stdio.h>
int main(){
	int desc[2];
	pipe(desc);
	printf("Um pipe foi criado\n");
	if(fork()==0){
		char mensagem[17]="O Brasil";
		printf("O processo filho ira escrever os dados no pipe\n");
		close(desc[0]);//fecha o pipe para leitura
		if(write(desc[1],mensagem,sizeof(mensagem))<0)
			printf("erro na escrita do pipe\n");
		close(desc[1]);
		sleep(1);
		return 0;
	} else {
		wait();
		char leitura[17];
		printf("O processo pai vai ler o pipe\n");
		close(desc[1]);//fechado para gravacao
		if(read(desc[0],leitura,17)==0){
			printf("pipe vazio\n");
		} else {
			printf("O valor lido e: %s\n",leitura);
		}
		close(desc[0]);//pipe fechado para leitura
		return 0;
	}
}
