#include <stdio.h>
#include <unistd.h>
//int execl(const char *arquivo, const char *args, ..., 0)
int main(){
	printf("Chamando o programa head para ler so o cabecalho do arquiv passwd\n");
	execl("/usr/bin/head", "head", "/etc/passwd", "/etc/group", (char *)0);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	for(int i=0; i<100;i++)
		printf("%d\n",i);
	return 0;
}
