#include <stdio.h>
#include <unistd.h>
#include <wait.h>
int main(){
	int pid, status;
	printf("Pid %d\n",getpid());
	pid=fork();
	if(pid==0){
		printf("Filho %d\n",getpid());
		for(;;);
	}else{
		sleep(5);
		printf("Enviando SIGKILL ao filho\n");
		kill(pid,9);
		wait(&status);
		printf("Filho terminou com exit = %d\n",WEXITSTATUS(status));
	}
	return 0;
}
