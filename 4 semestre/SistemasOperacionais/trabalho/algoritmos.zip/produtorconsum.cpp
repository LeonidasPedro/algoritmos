#include <cstdlib>
#include <iostream>
#include <windows.h>
using namespace std;
DWORD WINAPI produtor(LPVOID p);
DWORD WINAPI consumidor(LPVOID p);
int buffer=0;
int main(int argc, char *argv[])
{
  DWORD idt[2];    
  HANDLE th[2];
  while(true){
    if(buffer==0){
      th[0] = CreateThread(0,0,produtor,0,0,&idt[0]);
      WaitForMultipleObjects(1,th,0,INFINITE);                       
      TerminateThread(th[0],0);                                
      CloseHandle(th[0]);                                      
    } else {
      th[1] = CreateThread(0,0,consumidor,0,0,&idt[1]);
      WaitForMultipleObjects(1,th,0,INFINITE);
      TerminateThread(th[1],0);                                
      CloseHandle(th[1]);                                      
    }
  }
  CloseHandle(th);
  system("PAUSE");
  return EXIT_SUCCESS;
}
DWORD WINAPI produtor(LPVOID p){
   printf("\nIniciando produtor\n");
   while(buffer<100){
     buffer++;
     printf("%d\n",buffer);
     Sleep(100);
   }
}
DWORD WINAPI consumidor(LPVOID p){
   printf("\nIniciando consumidor\n");
   while(buffer>0){
     printf("%d\n",buffer);
     buffer--;
     Sleep(100);
   }
}
