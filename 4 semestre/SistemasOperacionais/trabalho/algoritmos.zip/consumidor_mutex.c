#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
pthread_t tid1, tid2;
pthread_mutex_t lock;
long conta=0;
void * t1(){
	long i;
	while(1){
		pthread_mutex_lock(&lock);
		while(conta < 1000000){
			conta++;
		}
		printf("Produtor ok %li", conta);
		pthread_mutex_unlock(&lock);
	}
}
void * t2(){
	long i;
	while(1){
		pthread_mutex_lock(&lock);
		while(conta>0){
			conta--;
		}
		printf("   -   Consumidor ok %li\n", conta);
		pthread_mutex_unlock(&lock);
	}
}
int main(){
	pthread_mutex_init(&lock, NULL);
	pthread_create(&tid1, NULL, t1, NULL);
	pthread_create(&tid2, NULL, t2, NULL);
	pthread_join(tid1, NULL);
	pthread_join(tid2, NULL);
	pthread_mutex_destroy(&lock);
}
