#include <unistd.h>
#include <bits/stdc++.h>
int main(){
	int i;
	while(scanf("%d",&i)==1){
		printf("%d\n",i);
		sleep(1);
	}
}