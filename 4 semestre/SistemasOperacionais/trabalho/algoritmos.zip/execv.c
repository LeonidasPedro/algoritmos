#include <stdio.h>
#include <unistd.h>
//int execv(const char *arquivo, char *argv[])
int main(){
	char *cmd[] = { "cat", "/etc/passwd", (char *)0};
	//cmd[] é um array de strings e necessariamente deve ser finalizado com um ponteiro nulo o (char *) 0
	printf("Chamando o cat para imprimir os dados do arquivo passwd\n");
	execv("/bin/cat", cmd);
	printf("Como o contexto de execucao foi alterado essa mensagem nao sera exibida");
	return 0;
}
