#include <signal.h>
#include <stdio.h>
#include <unistd.h>
int main(){
	int pid;
	printf("meu pid %d\n",getpid());
	pid = fork();
	if(pid==0){
		printf("\t\tMeu pid %d pid do pai %d\n",getpid(),getppid());
		printf("veja os processos em execucao com o ps\n");
		sleep(10);
		printf("processo filho terminou normalmente\n");
		return 0;
	} else {
		for(;;);
	}
}
