#include <stdio.h>
#include <unistd.h>
int main(){
	int pid;
	printf("Processo pai pid %d criando um processo filho\n",getpid());
	pid=fork();
	if(pid==0){
		printf("\t\tProcesso filho pid %d\n",getpid());
		printf("\t\tFilho ficara executando indefinidamente\n");
		for(;;);
	} else {
		sleep(4);
		printf("Processo pai termina e o filho fica orfao");
		printf("Use o comando ps para ver se o processo filho esta vivo");
	}
	return 0;
}
