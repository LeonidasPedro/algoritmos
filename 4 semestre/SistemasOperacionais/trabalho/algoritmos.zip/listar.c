#include <sys/types.h>
#include <stdio.h>
#include <sys/stat.h>
//./listar *
int main(int argc, char *argv[]){
	int i, type;
	struct stat statinfo;
	char *desc;
	for(i=1;i<argc;i++){
		if(lstat(argv[i],&statinfo)==-1){
			perror("lstat");
			return 1;
		}
		type = statinfo.st_mode & S_IFMT;
		switch(type){
			case S_IFDIR:
				desc = " - diretorio";
				break;
			case S_IFLNK:
				desc = " - link simbolico";
				break;
			case S_IFREG:
				desc = " - arquivo original";
				break;
			default:
				desc = " - outro tipo";
		}
		printf("%s e um %s\n",argv[i],desc);
	}
}
