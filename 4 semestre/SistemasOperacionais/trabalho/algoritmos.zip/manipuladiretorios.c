#include <stddef.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
int main(void){
	DIR *dp;
	struct dirent *ep;
	dp = opendir("/var/log");//grava o conted�do do diret�rio em dp
	if(dp !=NULL){
		while(ep=readdir(dp))//o ponteiro ep � apontado para a estrutura dirent
			puts(ep->d_name);
		(void) closedir (dp);
	} else
		puts("nao foi possivel abrir o diretorio\n");
	return 0;
}
