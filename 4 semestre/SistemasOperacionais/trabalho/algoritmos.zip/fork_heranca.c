#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
int main(){
	int pid;
	int fd;//arquivo aberto
	char pidnum[50];
	int r;//retorno do arquivo meupid
	int i;
	char c;//recebe conteudo do arquivo
	printf("Meu pid e %d",getpid());
	if((fd=open("meupid", O_CREAT|O_RDWR|O_TRUNC, S_IRWXU))==-1){
	//cria o arquivo meupid com permissoes de leitura e gravacao
		printf("arquivo nao criado");
		return 0;
	}
	sprintf(pidnum,"%d surpresa",getpid());
	if(write(fd,pidnum,15)==-1){
		printf("Nao foi possivel escrever no arquivo");
		return -1;
	}
	printf("\nNumero escrito fechando o arquivo\n");
	close(fd);
	printf("\nArquivo sendo aberto novamente para leitura\n");
	if((fd=open("meupid",O_RDONLY,S_IRWXU))==-1){
		printf("Nao foi possivel");
		return -1;
	}
	printf("\nCriando o processo filho\n");
	pid=fork();
	if(pid==-1){
		printf("Nao foi possivel criar o filho");
		return -1;
	} else if(pid==0){
		printf("\t\tProcesso filho pid %d\n",getpid());
		printf("\t\tLendo arquivo aberto pelo pai, herdado\n");
		for(i=1;i<=5;i++){
			if(read(fd,&c,1)==-1){
				printf("Nao li o arquivo");
				return -1;
			}
			printf("\n\t\tNumero lido %c\n",c);
		}
		printf("\nFechando arquivo e terminando execucao do filho\n");
		close(fd);
//		return 1;
	} else {//processo pai
		wait();//espera processo filho
		printf("\nO processo filho tinha o pid %d\n lendo arquivo meu pid\n",pid);
		while((r=read(fd,&c,1))!=0){
			if(r==-1){
				printf("impossivel ler");
				return 0;
			}
			printf("consegui ler -=> %c\n",c);
		}
		printf("\nO processo filho mexeu no ponteiro\nTerminando processo pai\n");
		close(fd);
	}
	return 0;
}
