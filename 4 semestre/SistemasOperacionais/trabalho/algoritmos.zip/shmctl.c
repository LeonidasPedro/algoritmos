#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <time.h>
#define CHAVE 123
int main(){
	int shmid;
	int tamanho = 1024;
	char *memoria;
	char *caminho = "/etc/passwd";
	struct shmid_ds shm_dados;
	if((shmid = shmget(ftok("",(key_t) CHAVE), tamanho, IPC_CREAT|IPC_EXCL|SHM_R|SHM_R))==-1){
		printf("J� existe\n");
		return 1;
	}
	printf("O segmento %d pode ser usado\n",shmid);
	if(shmctl(shmid,IPC_STAT,&shm_dados)==-1){
		printf("Erro ao ler dados\n");
		return 1;
	}
	printf("Dono do segmento %d\n",shm_dados.shm_perm.cuid);
	printf("Grupo dono %d\n",shm_dados.shm_perm.cgid);
	printf("Permissoes %#o\n",shm_dados.shm_perm.mode&0777);
	printf("PID criador %d\n",shm_dados.shm_cpid);
	printf("PID ultimo acesso %d\n",shm_dados.shm_lpid);
	printf("Tamanho segmento %d\n",(int) shm_dados.shm_segsz);
	if(shm_dados.shm_atime!=0)
	printf("Data ultimo acoplamento %s\n",ctime(&shm_dados.shm_atime));
	if(shm_dados.shm_dtime!=0)
	printf("Data ultimo desacoplamento %s\n",ctime(&shm_dados.shm_dtime));
	if(shm_dados.shm_ctime!=0)
	printf("Data ultima atualiza %s\n",ctime(&shm_dados.shm_ctime));
	printf("Numero de processos acoplados %d\n",(int) shm_dados.shm_nattch);
	if((shmctl(shmid, IPC_RMID,NULL))==-1){
		printf("Erro ao destruir segmento\n");
		return 1;
	}
}
