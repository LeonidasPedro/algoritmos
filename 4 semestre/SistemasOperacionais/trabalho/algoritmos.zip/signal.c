#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>
#include <stdlib.h>
void meusinal(sig){
//	int sig;
	printf("\t\tRecebi o sinal %d\n",sig);
	sleep(2);
	exit(5);
//	return 5;
}
int main(){
	int pid;
	int status;
	printf("pid %d", getpid());
	pid=fork();
	if(pid==0){
		signal(10,meusinal);//instrução de o que fazer quando receber o sinal
		printf("processo filho %d\n",getpid());
		for(;;)
			sleep(1);
	} else {
		sleep(5);
		printf("Enviando o sinal 10");
		kill(pid,10);
		wait(&status);
		printf("Filho terminou com exit = %d\n",WEXITSTATUS(status));
		if(WIFEXITED(status)){
//retorna false indicando o término normal do processo
			printf("\t\tO processo terminou de forma anormal\n");
		} else {
			printf("\t\tO processo terminou normalmente\n");
		}
		if(WIFSIGNALED(status)){
//retorna false se o término foi anormal
			printf("\t\tO processo terminou normalmente\n");
		} else {
			printf("\t\tO processo terminou de forma anormal\n");
		}
		if(WIFSTOPPED(status)){
//retorna true se o processo foi congelado
			printf("\t\tO processo foi congelado\n");
		}else{
			printf("\t\tO processo nao foi congelado\n");
		}
	}
	return 0;
}
